
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;
import java.sql.ResultSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author usrlab06
 */
public class Mysql {

    public Connection c;

    public int conectar(String IP, String porta, String database, String usuario, String senha) {
        int conectado = 0;
        try {
            String url = "jdbc:mysql://" + IP + ":" + porta + "/" + database + "?user=" + usuario + "&password=" + senha;
            c = (Connection) DriverManager.getConnection(url);
            conectado = 1;
        } catch (Exception e) {
        }
        return conectado;
    }

    public ResultSet consultar(String query) {
        ResultSet rs = null;
        try {
            Statement st = (Statement) c.createStatement();
            rs = st.executeQuery(query);
        } catch (Exception e) {
        }
        return rs;
    }
}
